const $ = require("jquery");
import "./footer.css";

$("body").append("<footer></footer>");
$("footer").append("<p>Copyright - Holberton School</p>");
