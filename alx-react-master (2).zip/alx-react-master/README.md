This directory is for learning about React and how best to implement in everyday tasks.
