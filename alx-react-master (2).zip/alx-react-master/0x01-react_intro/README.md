Learning about React, and implementing as I go.
